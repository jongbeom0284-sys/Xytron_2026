"""터미널 WASD 텔레옵 — 웹 대시보드 대신 ssh 터미널에서 수동주행.

    ros2 run kmu_race teleop                          # 실차 (xycar_motor)
    ros2 run kmu_race teleop --topic /kmu_smoke_motor # 무해 벤치 테스트

키:
    w / s   전진 / 후진 (누르는 동안 — 키를 떼면 0.7s 안에 스스로 정지)
    a / d   좌 / 우 조향 (떼면 중앙 복귀)
    1 ~ 9   순항속도 = 숫자 × 2  (기본 8)
    space   즉시 정지 래치 (w/s 를 다시 누르면 해제)
    q       정지 후 종료

터미널에는 키 '뗌' 이벤트가 없으므로 OS 자동반복(키 홀드 시 연속 입력)을
데드맨으로 쓴다 — 입력이 0.7s 끊기면 속도 0, 조향 중앙. 그래서 브라우저
WASD 와 달리 연결이 끊겨도, 손을 떼도, 터미널이 죽어도 차는 멈춘다.
종료 시(정상/Ctrl-C 모두) 정지 명령을 5회 발행한다.
"""

from __future__ import annotations

import argparse
import select
import sys
import termios
import time
import tty

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray

DEADMAN_S = 0.7      # 자동반복 초기 지연(~0.5s)보다 길어야 홀드가 안 끊긴다
STEER_DEG = 28.0
RATE_HZ = 25.0


def main(argv=None) -> None:
    p = argparse.ArgumentParser(description="kmu_race 터미널 텔레옵")
    p.add_argument("--topic", default="xycar_motor")
    p.add_argument("--speed", type=float, default=8.0, help="초기 순항속도")
    p.add_argument("--steer", type=float, default=STEER_DEG)
    args, _ = p.parse_known_args(argv)

    rclpy.init()
    node = Node("kmu_teleop")
    pub = node.create_publisher(Float32MultiArray, args.topic, 1)
    msg = Float32MultiArray()

    cruise = float(args.speed)
    steer_deg = float(args.steer)
    last_fwd = last_rev = last_left = last_right = 0.0
    stop_latch = False

    fd = sys.stdin.fileno()
    is_tty = sys.stdin.isatty()
    old_attr = None
    if is_tty:
        old_attr = termios.tcgetattr(fd)
        tty.setcbreak(fd)
        # cbreak 는 echo 를 남긴다 — 조종 키가 화면을 어지럽히지 않게 끈다.
        no_echo = termios.tcgetattr(fd)
        no_echo[3] &= ~termios.ECHO
        termios.tcsetattr(fd, termios.TCSADRAIN, no_echo)

    print(
        f"teleop → {args.topic}\n"
        f"  w/s 전후진 · a/d 조향(±{steer_deg:.0f}) · 1~9 속도(현재 {cruise:.0f}) "
        f"· space 정지 · q 종료\n"
        f"  키를 떼면 {DEADMAN_S:.1f}s 안에 자동 정지 (데드맨)",
        flush=True,
    )

    try:
        period = 1.0 / RATE_HZ
        last_status = 0.0
        while True:
            readable, _, _ = select.select([sys.stdin], [], [], period)
            now = time.monotonic()
            if readable:
                ch = sys.stdin.read(1)
                if ch == "" or ch == "q":          # EOF(파이프) 또는 종료
                    break
                elif ch == " ":
                    stop_latch = True
                elif ch in ("w", "W"):
                    last_fwd = now
                    stop_latch = False
                elif ch in ("s", "S"):
                    last_rev = now
                    stop_latch = False
                elif ch in ("a", "A"):
                    last_left = now
                elif ch in ("d", "D"):
                    last_right = now
                elif ch.isdigit() and ch != "0":
                    cruise = float(ch) * 2.0

            speed = 0.0
            if not stop_latch:
                if now - last_fwd < DEADMAN_S:
                    speed = cruise
                elif now - last_rev < DEADMAN_S:
                    speed = -cruise * 0.6

            left = (now - last_left) < DEADMAN_S
            right = (now - last_right) < DEADMAN_S
            angle = 0.0
            if left and not right:
                angle = -steer_deg
            elif right and not left:
                angle = +steer_deg

            msg.data = [float(angle), float(speed)]
            pub.publish(msg)

            if now - last_status > 0.5:
                last_status = now
                state = "STOP" if stop_latch else ("DRIVE" if speed else "idle")
                print(
                    f"\r  angle={angle:+6.1f}  speed={speed:+6.1f}  "
                    f"cruise={cruise:4.1f}  [{state}]   ",
                    end="",
                    flush=True,
                )
    except KeyboardInterrupt:
        pass
    finally:
        for _ in range(5):
            msg.data = [0.0, 0.0]
            pub.publish(msg)
            time.sleep(0.03)
        if is_tty and old_attr is not None:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_attr)
        print("\n정지 명령 5회 발행 — teleop 종료", flush=True)
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
