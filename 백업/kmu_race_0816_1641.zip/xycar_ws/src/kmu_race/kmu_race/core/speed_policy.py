"""속도 정책 — 4분 예산(규정 p.37) 안에 3바퀴를 넣기 위한 계층.

세 가지를 겹쳐서 최종 목표속도를 만든다.
  1) 모드별 기본속도      : 라바콘은 느리게, 직선은 빠르게
  2) 곡률·조향 기반 감속  : 코너에서 알아서 줄인다
  3) 시간 압박 보정       : 뒤처지고 있으면 전 구간을 올린다

마지막에 램프(가감속 제한)를 걸어 급가속으로 인한 휠스핀과 급감속으로 인한
피치 변화(카메라 시야 흔들림)를 막는다.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional


@dataclass
class SpeedConfig:
    # 모드별 기본 목표속도 [자이카 단위]
    base: Dict[str, float] = field(
        default_factory=lambda: {
            "WAIT_GREEN": 0.0,
            "LANE_DRIVE": 20.0,
            "CONE_DRIVE": 11.0,
            "AVOID_STATIC": 13.0,
            "OVERTAKE": 15.0,
            "SHORTCUT": 12.0,
            "FINISH": 0.0,
            "STOP": 0.0,
        }
    )
    min_speed: float = 8.0
    max_speed: float = 26.0

    # 조향이 클수록 감속. |steer| 가 steer_full_slow 일 때 curve_min_ratio 배가 된다.
    steer_full_slow_deg: float = 34.0
    curve_min_ratio: float = 0.55

    # 시간 압박이 1.0 일 때 기본속도에 곱하는 값
    pressure_boost: float = 1.30

    # 램프 [단위/초]
    ramp_up_per_s: float = 22.0
    ramp_down_per_s: float = 40.0

    # 퍼셉션 열화 시(safety DEGRADED) 상한
    degraded_speed: float = 9.0


class SpeedPolicy:
    def __init__(self, config: Optional[SpeedConfig] = None) -> None:
        self.config = config or SpeedConfig()
        self._current = 0.0
        self._last_t: Optional[float] = None

    def reset(self) -> None:
        self._current = 0.0
        self._last_t = None

    def target_for(
        self,
        mode: str,
        *,
        steer_deg: float,
        time_pressure: float,
        override: Optional[float] = None,
        degraded: bool = False,
    ) -> float:
        """램프 적용 전의 목표속도."""
        cfg = self.config
        base = cfg.base.get(mode, cfg.base["LANE_DRIVE"])
        if override is not None:
            base = override
        if base <= 0.0:
            return 0.0

        # 곡선 감속
        ratio = 1.0 - (1.0 - cfg.curve_min_ratio) * min(
            1.0, abs(steer_deg) / max(1e-3, cfg.steer_full_slow_deg)
        )
        target = base * ratio

        # 시간 압박 보정. 미션 구간에서는 올리지 않는다 — 거기서 서두르면
        # 라바콘 충돌(3초)·추돌(10초)로 오히려 손해다.
        if mode in ("LANE_DRIVE", "SHORTCUT"):
            target *= 1.0 + (cfg.pressure_boost - 1.0) * max(
                0.0, min(1.0, time_pressure)
            )

        if degraded:
            target = min(target, cfg.degraded_speed)

        return max(cfg.min_speed, min(cfg.max_speed, target))

    def step(self, target: float, now: float) -> float:
        """램프를 적용해 실제 발행할 속도를 만든다."""
        cfg = self.config
        if self._last_t is None:
            self._last_t = now
            # 출발 순간부터 램프를 태운다 (정지 → 목표 급발진 방지)
            self._current = 0.0 if target > 0.0 else target
            return self._current

        dt = max(1e-3, now - self._last_t)
        self._last_t = now

        if target > self._current:
            self._current = min(self._current + cfg.ramp_up_per_s * dt, target)
        else:
            self._current = max(self._current - cfg.ramp_down_per_s * dt, target)
        return self._current

    @property
    def current(self) -> float:
        return self._current


__all__ = ["SpeedConfig", "SpeedPolicy"]
