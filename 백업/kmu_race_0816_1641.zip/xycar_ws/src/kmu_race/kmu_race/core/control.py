"""조향 계산 — 퓨어 퍼수트와 픽셀-오차 PID.

자이카 축거(wheelbase)는 0.30m 이다 (자이카 ROS2 미니PC Y모델).
퓨어 퍼수트를 쓰는 이유: 픽셀 오차 PID 는 저속에선 잘 듣지만 속도가 올라가면
같은 게인이 과조향을 만든다. 4분 제한(규정 p.37) 안에 3바퀴를 넣으려면 고속
구간이 필수라 속도에 따라 전방주시거리가 늘어나는 기하 기반 제어가 유리하다.

조향 부호: 음수 = 좌회전, 양수 = 우회전 (자이카 실차 규약).
"""

from __future__ import annotations

import math
from dataclasses import dataclass

WHEELBASE_M = 0.30


def pure_pursuit_steer(
    target_x: float,
    target_y: float,
    *,
    wheelbase: float = WHEELBASE_M,
    max_steer: float = 50.0,
) -> float:
    """차량 기준 목표점(x 전방+, y 좌측+)을 향하는 조향각 [deg].

    δ = atan2(2·L·sin(α), Ld),  α = 목표점 방위각, Ld = 목표점까지 거리.
    y>0(좌측)이면 좌회전이어야 하므로 부호를 뒤집어 반환한다.
    """
    ld_sq = target_x * target_x + target_y * target_y
    if ld_sq < 1e-6:
        return 0.0
    ld = math.sqrt(ld_sq)
    alpha = math.atan2(target_y, target_x)
    delta = math.atan2(2.0 * wheelbase * math.sin(alpha), ld)
    steer = -math.degrees(delta)
    return max(-max_steer, min(max_steer, steer))


@dataclass
class PixelPID:
    """BEV 픽셀 오차용 PID. 차선주행 기본 제어.

    적분항은 기본으로 꺼 둔다(Ki=0). 켤 거면 반드시 anti-windup 을 함께 켤 것 —
    픽셀 오차는 차선을 놓친 프레임에 크게 튀어서 적분이 순식간에 폭주한다.
    """

    kp: float = 0.16
    ki: float = 0.0
    kd: float = 0.27
    deadzone_px: float = 10.0
    max_steer: float = 50.0
    integral_limit: float = 400.0

    _prev: float = 0.0
    _integral: float = 0.0

    def reset(self) -> None:
        self._prev = 0.0
        self._integral = 0.0

    def update(self, error_px: float) -> float:
        if abs(error_px) < self.deadzone_px:
            error_px = 0.0

        self._integral += error_px
        # anti-windup: 적분항을 물리적으로 의미 있는 범위에 가둔다.
        self._integral = max(
            -self.integral_limit, min(self.integral_limit, self._integral)
        )
        derivative = error_px - self._prev
        self._prev = error_px

        steer = self.kp * error_px + self.ki * self._integral + self.kd * derivative
        return max(-self.max_steer, min(self.max_steer, steer))


@dataclass
class SteerSmoother:
    """이동평균 + 슬루 제한. 서보 떨림과 급조향을 억제한다."""

    window: int = 5
    max_rate_deg_per_s: float = 420.0

    def __post_init__(self) -> None:
        self._hist: list[float] = []
        self._last: float = 0.0
        self._last_t: float | None = None

    def reset(self) -> None:
        self._hist.clear()
        self._last = 0.0
        self._last_t = None

    def update(self, steer: float, now: float) -> float:
        self._hist.append(steer)
        if len(self._hist) > max(1, self.window):
            self._hist.pop(0)
        smoothed = sum(self._hist) / len(self._hist)

        if self._last_t is None:
            self._last_t = now
            self._last = smoothed
            return smoothed

        dt = max(1e-3, now - self._last_t)
        max_delta = self.max_rate_deg_per_s * dt
        delta = smoothed - self._last
        if delta > max_delta:
            smoothed = self._last + max_delta
        elif delta < -max_delta:
            smoothed = self._last - max_delta

        self._last = smoothed
        self._last_t = now
        return smoothed


__all__ = ["WHEELBASE_M", "pure_pursuit_steer", "PixelPID", "SteerSmoother"]
