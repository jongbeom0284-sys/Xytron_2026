"""4구 신호등 인식 (규정 p.17~p.20, p.35~p.36).

램프 배치는 규정 도면에 확정돼 있다 — 좌→우 [빨강, 노랑, 좌회전←, 녹색].
점등 조합도 규정이 못박아 준다:
    출발      빨강        → 녹색            (직진 출발)
    2랩 시작  녹색        → 녹색+좌회전     (직좌 동시신호) 또는 녹색 유지
    3랩 시작  녹색                          (직진만)

그래서 '색'으로 푸는 게 아니라 **'네 번째 램프가 켜졌나 / 세 번째가 켜졌나'**
로 푼다. 색 기반 판정은 라바콘 주황을 빨강으로 오인하는 알려진 함정이 있는데,
위치 기반은 애초에 그 문제를 만들지 않는다.

구현 출처: mastic-choi/UMK `perception/traffic_signal.py` 의 HoughCircles + 배치검증
+ 조합 전수탐색 방식을 따랐다. 반사광으로 원이 4개보다 많이 잡히는 상황이 실차에서
흔하기 때문에 그 완화 처리가 특히 중요하다.

랩 마커 (`gantry_span_px`) — 2026-08-13 재설계:
  대회장(강의실형 실내)의 천장 조명이 HoughCircles 에 '일렬·등간격 원 조합'
  으로 잡힌다는 것이 run4 bag 포렌식으로 확정됐다 — 검증 span 상위 12개
  에피소드의 피크 프레임을 전수 육안 판정한 결과 12개 전부 조명이었고
  겐트리는 0개였다. 원 기반 span 은 이 대회장에서 랩 마커로 **불성립**한다.

  대신 **채도 있는 초록 램프 블롭의 가로폭**을 쓴다. 주행 중 신호등은 항상
  초록 계열(GREEN/GREEN_LEFT)이 점등돼 있고, 조명은 무채색(형광등) 또는
  주황(목재구간 펜던트)이라 '채도 초록'이 겐트리 고유 시그니처다.
  실측(run4, 38~42s 접근): H 75~95 / S 60~120 / V 130~255,
  블롭 폭 7px(원거리) → 14px → 35px(통과 직전).

  점등 분류(state)와는 독립이다 — 어떤 램프가 켜졌는지 못 읽어도 겐트리
  통과 사실은 랩 마커로 잡혀야 한다 (core/race_context.py LapTracker).

점등 분류의 채도 게이트 (같은 날 추가):
  '밝기만'으로 lit 을 정하면 천장 조명 원이 무작위 RED/GREEN/GREEN_LEFT 를
  만든다 (run4 에서 695프레임 오분류 실측 — 가짜 GREEN_LEFT 는 지름길
  오발동으로 직결). 그래서 lit 판정에 밝기 AND 해당 색 채도를 요구한다.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple

import cv2
import numpy as np

from ..core.types import SignalReading, SignalState


@dataclass
class SignalConfig:
    """실차 튜닝 대상. config/params.yaml 에서 덮어쓴다."""

    # ROI (프레임 비율). 신호등은 화면 상단에 걸린다.
    roi_top: float = 0.05
    roi_bottom: float = 0.45
    roi_left: float = 0.20
    roi_right: float = 0.85

    min_radius: int = 8
    max_radius: int = 26
    # HoughCircles 파라미터
    hough_param1: int = 40
    hough_param2: int = 20
    hough_min_dist: int = 18

    # 점등 판정: 램프 밝기가 4개 평균보다 이만큼 밝으면 켜진 것
    bright_margin: float = 15.0
    # 원이 이보다 많이 잡히면 노이즈로 보고 포기 (조합 폭발 방지)
    max_candidates: int = 9

    # ── 채도 게이트 (run4 bag 실측 기반, 모듈 주석 참조) ──
    # 초록 램프 실측 H 75~95 — 약간의 여유를 둔다.
    green_h: Tuple[int, int] = (68, 98)
    # 빨강은 H 가 0 근처에서 감긴다: 0~red_h_max 또는 red_h_wrap~180
    red_h_max: int = 12
    red_h_wrap: int = 168
    chroma_min_s: int = 55          # 형광등(무채색) 배제 임계
    lamp_min_v: int = 110
    # lit 판정 시 램프 패치에서 해당 색 픽셀이 차지해야 하는 최소 비율
    color_frac_min: float = 0.20

    # ── 초록 램프 블롭 (랩 마커) ──
    # run4 bag 전수 A/B(설정 4종 × 11,056프레임)로 확정한 값. 이 조합에서
    # 진짜 통과 32px vs 최악 오검 14px 로 2배 이상 분리된다.
    blob_min_px: int = 8            # 이보다 작은 블롭은 노이즈
    blob_min_v: int = 170           # 램프는 발광체 — 창밖 수풀(V 낮음) 배제
    blob_fill_min: float = 0.55     # 원형 채움비 — 너덜한 반사 배제
    blob_max_aspect: float = 2.0    # 가로판(비상구 표지 등) 배제
    # 소등 램프 검사: 진짜 신호등이면 초록 왼쪽에 꺼진 램프(어두운 원)들이
    # 있다 (규정 배치 좌→우 [빨,노,좌,녹] — 초록 계열은 항상 오른쪽).
    # 단독 초록 발광체(비상구 유도등)를 구조적으로 걸러낸다.
    unlit_v_max: int = 90
    unlit_dark_frac_min: float = 0.15

    # 배치 검증 — min/max_radius 에서 파생되는 값이라 "N배" 관계를 그대로 둔다.
    @property
    def vert_diff_max(self) -> int:
        return self.max_radius * 2

    @property
    def horiz_diff_max(self) -> int:
        return self.max_radius * 11

    @property
    def min_gap(self) -> int:
        return self.min_radius * 3


class SignalDetector:
    """한 프레임 → SignalReading. 프레임 간 디바운스는 상위(FSM)가 한다."""

    def __init__(self, config: Optional[SignalConfig] = None) -> None:
        self.config = config or SignalConfig()
        self.roi: Optional[np.ndarray] = None
        self.last: SignalReading = SignalReading()

    # ── 기하 검증 ─────────────────────────────────────────────────
    def _shape_ok(self, circles: Sequence) -> Tuple[bool, str]:
        cfg = self.config
        xs = sorted(int(c[0]) for c in circles)
        ys = sorted(int(c[1]) for c in circles)

        if (ys[-1] - ys[0]) > cfg.vert_diff_max:
            return False, f"vert_spread={ys[-1] - ys[0]}>{cfg.vert_diff_max}"
        if (xs[-1] - xs[0]) > cfg.horiz_diff_max:
            return False, f"horiz_spread={xs[-1] - xs[0]}>{cfg.horiz_diff_max}"
        for i in range(len(xs) - 1):
            if (xs[i + 1] - xs[i]) < cfg.min_gap:
                return False, f"gap[{i}]={xs[i + 1] - xs[i]}<{cfg.min_gap}"
        return True, ""

    def _pick_best_4(self, circles: Sequence) -> Tuple[Optional[List], str]:
        """원이 4개보다 많이 잡혔을 때 가장 신호등다운 4개 조합을 고른다.

        여러 조합이 배치검증을 통과하면 세로 퍼짐이 가장 작은 것을 택한다 —
        같은 높이에 나란할수록 진짜 신호등일 확률이 높다는 가정.
        """
        best, best_score = None, None
        for combo in itertools.combinations(circles, 4):
            ok, _ = self._shape_ok(combo)
            if not ok:
                continue
            ys = [c[1] for c in combo]
            score = max(ys) - min(ys)
            if best_score is None or score < best_score:
                best, best_score = combo, score
        if best is None:
            return None, "no_valid_4subset"
        return list(best), ""

    @staticmethod
    def _brightness(gray: np.ndarray, x: int, y: int, r: int) -> float:
        """램프 중심 패치의 평균 밝기. 반경의 절반만 써서 테두리를 배제한다."""
        half = max(1, r // 2)
        y0, y1 = max(0, y - half), y + half
        x0, x1 = max(0, x - half), x + half
        patch = gray[y0:y1, x0:x1]
        if patch.size == 0:
            return 0.0
        return float(np.mean(patch))

    def _color_frac(self, hsv: np.ndarray, x: int, y: int, r: int, color: str) -> float:
        """램프 패치에서 해당 색(채도 포함) 픽셀의 비율.

        '밝기만'으로 lit 을 정하면 무채색 천장 조명이 켜진 램프로 오인된다.
        점등 램프는 반드시 유채색이므로 색 비율을 함께 요구한다.
        """
        cfg = self.config
        half = max(1, r // 2)
        y0, y1 = max(0, y - half), y + half
        x0, x1 = max(0, x - half), x + half
        patch = hsv[y0:y1, x0:x1]
        if patch.size == 0:
            return 0.0
        hh, ss, vv = patch[..., 0], patch[..., 1], patch[..., 2]
        sat = (ss >= cfg.chroma_min_s) & (vv >= cfg.lamp_min_v)
        if color == "red":
            hue = (hh <= cfg.red_h_max) | (hh >= cfg.red_h_wrap)
        else:  # green
            hue = (hh >= cfg.green_h[0]) & (hh <= cfg.green_h[1])
        return float(np.count_nonzero(sat & hue)) / float(hh.size)

    def _green_lamp_span(self, hsv: np.ndarray) -> int:
        """랩 마커: 채도 있는 초록 램프 블롭의 가로폭 [px]. 없으면 0.

        원 검출과 완전히 독립이다 — 천장 조명이 원 조합을 오염시켜도
        '채도 초록' 블롭은 겐트리(초록/좌회전 점등)에서만 나온다는 것이
        run4 bag 실측의 결론이다 (모듈 주석 참조).
        """
        cfg = self.config
        h, s, v = cv2.split(hsv)
        mask = (
            (h >= cfg.green_h[0]) & (h <= cfg.green_h[1])
            & (s >= cfg.chroma_min_s) & (v >= cfg.blob_min_v)
        ).astype(np.uint8) * 255
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        n, _labels, stats, _cent = cv2.connectedComponentsWithStats(mask)
        best = 0
        for i in range(1, n):
            x, y, bw, bh, area = (int(stats[i][k]) for k in range(5))
            if area < cfg.blob_min_px:
                continue
            aspect = max(bw / max(1, bh), bh / max(1, bw))
            if aspect > cfg.blob_max_aspect:
                continue
            if area / float(bw * bh) < cfg.blob_fill_min:
                continue
            # 소등 램프 검사 — 블롭 왼쪽 스트립에 어두운(꺼진 램프) 픽셀이
            # 충분히 있어야 한다. 왼쪽이 프레임 밖이면(통과 직전 초근접)
            # 이 블롭은 버리지만, 그 전 접근 프레임들에서 이미 목격이
            # 확정되므로 랩 카운팅에는 문제가 없다.
            x0s = max(0, x - int(3.6 * bw))
            x1s = max(0, x - max(1, int(0.3 * bw)))
            y0s = max(0, y - int(0.2 * bh))
            y1s = min(v.shape[0], y + int(1.2 * bh))
            strip = v[y0s:y1s, x0s:x1s]
            if strip.size == 0:
                continue
            dark = np.count_nonzero(strip < cfg.unlit_v_max) / float(strip.size)
            if dark < cfg.unlit_dark_frac_min:
                continue
            best = max(best, bw)
        return best

    # ── 메인 ──────────────────────────────────────────────────────
    def detect(self, frame: Optional[np.ndarray]) -> SignalReading:
        if frame is None:
            self.last = SignalReading(reject_reason="no_frame")
            return self.last

        cfg = self.config
        h, w = frame.shape[:2]
        t, b = int(h * cfg.roi_top), int(h * cfg.roi_bottom)
        l, r = int(w * cfg.roi_left), int(w * cfg.roi_right)
        self.roi = frame[t:b, l:r]

        # 랩 마커는 원 검출과 독립적으로, 채도 초록 블롭에서 먼저 계산한다.
        hsv = cv2.cvtColor(self.roi, cv2.COLOR_BGR2HSV)
        gantry_span = self._green_lamp_span(hsv)

        gray = cv2.cvtColor(self.roi, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        found = cv2.HoughCircles(
            blur,
            cv2.HOUGH_GRADIENT,
            1,
            cfg.hough_min_dist,
            param1=cfg.hough_param1,
            param2=cfg.hough_param2,
            minRadius=cfg.min_radius,
            maxRadius=cfg.max_radius,
        )

        if found is None:
            self.last = SignalReading(
                reject_reason="no_circles", gantry_span_px=gantry_span
            )
            return self.last

        circles = np.round(found[0, :]).astype(int)
        n = len(circles)

        if n > cfg.max_candidates:
            self.last = SignalReading(
                circle_count=n,
                reject_reason=f"circle_count={n}(>{cfg.max_candidates}, noisy)",
                gantry_span_px=gantry_span,
            )
            return self.last
        if n < 4:
            self.last = SignalReading(
                circle_count=n,
                reject_reason=f"circle_count={n}(<4)",
                gantry_span_px=gantry_span,
            )
            return self.last

        if n == 4:
            ok, reason = self._shape_ok(circles)
            chosen = list(circles) if ok else None
        else:
            chosen, reason = self._pick_best_4(circles)

        if chosen is None:
            self.last = SignalReading(
                circle_count=n,
                reject_reason=f"circle_count={n} {reason}",
                gantry_span_px=gantry_span,
            )
            return self.last

        # 좌→우 정렬 = [빨강, 노랑, 좌회전, 녹색]
        ordered = sorted(chosen, key=lambda c: c[0])
        bright = [self._brightness(gray, int(x), int(y), int(rr)) for x, y, rr in ordered]
        avg = float(np.mean(bright))
        lit = [bv - avg > cfg.bright_margin for bv in bright]

        # 채도 게이트 — 무채색으로 밝은 것(천장 조명·반사)은 켜진 램프가 아니다.
        # 가짜 GREEN_LEFT 한 번이면 지름길 오발동(=차선이탈)이라 여기서 막는다.
        def _lit_chroma(idx: int, color: str) -> bool:
            x, y, rr = int(ordered[idx][0]), int(ordered[idx][1]), int(ordered[idx][2])
            return (
                lit[idx]
                and self._color_frac(hsv, x, y, rr, color) >= cfg.color_frac_min
            )

        red_lit = _lit_chroma(0, "red")
        left_lit = _lit_chroma(2, "green")
        green_lit = _lit_chroma(3, "green")

        # 규정에 실제로 존재하는 조합만 상태로 매핑한다.
        if green_lit and left_lit:
            state = SignalState.GREEN_LEFT   # 직좌 동시신호 → 지름길 가능
        elif green_lit:
            state = SignalState.GREEN
        elif red_lit:
            state = SignalState.RED
        else:
            state = SignalState.UNKNOWN

        self.last = SignalReading(
            state=state,
            lamp_brightness=tuple(round(v, 1) for v in bright),
            circle_count=n,
            reject_reason="" if state is not SignalState.UNKNOWN else "no_lamp_lit",
            gantry_span_px=gantry_span,
        )
        return self.last

    # ── 디버그 오버레이 ───────────────────────────────────────────
    def annotate(self) -> Optional[np.ndarray]:
        """튜닝용 시각화. 대회 당일에는 호출하지 않는다 (GUI 가 프레임을 잡아먹음)."""
        if self.roi is None:
            return None
        vis = self.roi.copy()
        r = self.last
        color = {
            SignalState.GREEN: (0, 255, 0),
            SignalState.GREEN_LEFT: (0, 255, 255),
            SignalState.RED: (0, 0, 255),
            SignalState.UNKNOWN: (150, 150, 150),
        }[r.state]
        cv2.putText(
            vis,
            f"{r.state.value} n={r.circle_count} span={r.gantry_span_px}",
            (4, 18),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.45,
            color,
            1,
            cv2.LINE_AA,
        )
        if r.reject_reason:
            cv2.putText(
                vis, r.reject_reason, (4, 36),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (180, 180, 180), 1, cv2.LINE_AA,
            )
        return vis


__all__ = ["SignalConfig", "SignalDetector"]
