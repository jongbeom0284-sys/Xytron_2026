"""라바콘 검출 — 좌우 두 줄 사이의 '게이트'를 찾는다 (규정 p.23~p.25).

규정 도면은 콘이 **좌우 두 줄**로 놓이고 그 사이를 뱀처럼 통과하는 형태다.
그래서 흔한 구현 방식인 '주황 마스크 히스토그램의 argmax 하나를 추종'은
위험하다 — 픽셀이 많은 한쪽 줄만 따라가게 되고, 콘을 건드리면 개당 3초다.

여기서는 BEV 에서 가까운 밴드를 잘라 주황 컨투어를 좌/우로 가르고,
**양쪽에서 가장 안쪽에 있는 콘** 두 개를 골라 그 중점을 게이트 중앙으로 삼는다.
한쪽만 보이면 gate_valid=False 로 보고하고, 상위(policy)가 반발 조향으로
대체한다.

주황 HSV 기본값은 팀이 실차에서 튜닝한 값(`segi/my_driver_labacorn.py` 의
[0,108,224]~[28,255,255])을 기준으로 잡았다.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Tuple

import cv2
import numpy as np

from ..core.types import ConeReading


@dataclass
class ConeConfig:
    # 주황 HSV
    lower: Tuple[int, int, int] = (0, 108, 224)
    upper: Tuple[int, int, int] = (28, 255, 255)

    # 게이트를 찾을 밴드 — BEV ROI 하단에서 이 비율만큼. 가까운 콘만 본다.
    band_top: float = 0.35
    band_bottom: float = 1.0

    # 콘 하나로 인정할 최소 컨투어 면적
    min_area: int = 90
    # 구간 진입 판정에 쓸 전체 주황 픽셀 최소치
    min_section_px: int = 900

    # 게이트로 인정할 좌우 콘 사이 최소 간격 [px].
    # 차폭이 통과 가능한 폭이어야 한다. BEV px_per_m 기준으로 잡을 것.
    min_gate_px: float = 110.0
    # 게이트 후보가 너무 넓으면 콘 두 줄이 아니라 서로 다른 구간을 본 것이다.
    max_gate_px: float = 620.0


class ConeDetector:
    def __init__(self, config: Optional[ConeConfig] = None) -> None:
        self.config = config or ConeConfig()
        self.mask: Optional[np.ndarray] = None
        self._last_gate: float = 0.0

    def detect(self, bev_roi: Optional[np.ndarray]) -> ConeReading:
        """입력은 LaneDetector 와 같은 BEV ROI (warped 하단 절반)."""
        if bev_roi is None:
            return ConeReading()

        cfg = self.config
        h, w = bev_roi.shape[:2]
        hsv = cv2.cvtColor(bev_roi, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, np.array(cfg.lower), np.array(cfg.upper))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
        self.mask = mask

        total_px = int(np.count_nonzero(mask))
        if total_px < cfg.min_section_px:
            return ConeReading(detected=False, orange_px=total_px)

        y0 = int(h * cfg.band_top)
        y1 = int(h * cfg.band_bottom)
        band = mask[y0:y1, :]

        cnts, _ = cv2.findContours(
            band, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )

        center = w / 2.0
        cones: List[Tuple[float, int]] = []   # (cx, area)
        for cnt in cnts:
            area = cv2.contourArea(cnt)
            if area < cfg.min_area:
                continue
            m = cv2.moments(cnt)
            if m["m00"] == 0:
                continue
            cones.append((m["m10"] / m["m00"], int(area)))

        # 좌/우를 화면 중앙으로 가르지 않는다. 콘 통로가 곡선에서 화면 한쪽으로
        # 통째로 밀리면 그 방식은 양쪽 줄을 모두 '왼쪽'으로 분류해 버린다.
        # 대신 콘들을 x 로 정렬해 **가장 넓은 간격**을 찾는다. 그 틈이 곧
        # 차가 지나갈 게이트다. 통로가 화면 어디에 있든 성립한다.
        gate_valid = False
        gate = self._last_gate
        inner_l = inner_r = None

        if len(cones) >= 2:
            xs = sorted(c[0] for c in cones)
            best_gap, best_pair = 0.0, None
            for a, b in zip(xs, xs[1:]):
                gap = b - a
                if gap > best_gap:
                    best_gap, best_pair = gap, (a, b)
            if best_pair and cfg.min_gate_px <= best_gap <= cfg.max_gate_px:
                inner_l, inner_r = best_pair
                gate = (inner_l + inner_r) / 2.0 - center
                self._last_gate = gate
                gate_valid = True

        # 좌/우 콘 픽셀은 게이트를 기준으로 나눈다 (게이트가 없으면 화면 중앙).
        split = center + (gate if gate_valid else 0.0)
        left_px = sum(a for cx, a in cones if cx < split)
        right_px = sum(a for cx, a in cones if cx >= split)

        return ConeReading(
            detected=True,
            orange_px=total_px,
            left_cone_px=int(left_px),
            right_cone_px=int(right_px),
            gate_center_px=float(gate),
            gate_valid=gate_valid,
        )


__all__ = ["ConeConfig", "ConeDetector"]
