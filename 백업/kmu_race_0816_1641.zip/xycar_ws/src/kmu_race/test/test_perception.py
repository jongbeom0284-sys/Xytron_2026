"""퍼셉션 스모크 테스트 — 합성 입력으로 '죽지 않는가'와 '방향이 맞는가'를 본다.

실차 정확도는 여기서 못 잰다. 그건 연습주행에서 bag 을 받아 맞춰야 한다.
여기서 잡으려는 건 대회 당일에 나면 끝장인 것들이다:
  · 프레임이 비었을 때 예외로 노드가 죽는가
  · 부호가 뒤집혀 있는가 (왼쪽 차선인데 우조향이 나온다든가)
  · 스캔 길이가 바뀌었을 때 인덱스 에러가 나는가
"""

import math

import pytest

cv2 = pytest.importorskip("cv2")
np = pytest.importorskip("numpy")

from kmu_race.core.types import SignalState  # noqa: E402
from kmu_race.perception.cone_detector import ConeDetector  # noqa: E402
from kmu_race.perception.lane_detector import LaneDetector  # noqa: E402
from kmu_race.perception.lidar_tracker import LidarTracker  # noqa: E402
from kmu_race.perception.signal_detector import SignalDetector  # noqa: E402

W, H = 640, 480


def road_frame(left_x=140, right_x=500):
    """흰 차선 두 줄이 그려진 합성 프레임."""
    img = np.full((H, W, 3), 40, np.uint8)
    cv2.line(img, (left_x, H), (left_x + 40, H // 2), (255, 255, 255), 12)
    cv2.line(img, (right_x, H), (right_x - 40, H // 2), (255, 255, 255), 12)
    return img


def signal_frame(lit_index, n_lamps=4, cx=320, cy=110, gap=46, r=15):
    """4구 신호등 합성. lit_index 에 해당하는 램프만 켠다.

    점등 램프는 실물처럼 **유채색**으로 그린다 (검출기의 채도 게이트가
    무채색 밝음 = 천장 조명을 걸러내므로, 흰색으로 그리면 실물과 다르게
    lit 판정에서 탈락하는 게 맞다). 색은 run4 bag 실측 HSV 를 BGR 로 옮긴 것.
    """
    img = np.full((H, W, 3), 30, np.uint8)
    x0 = cx - (n_lamps - 1) * gap // 2
    cv2.rectangle(
        img,
        (x0 - 32, cy - 30),
        (x0 + (n_lamps - 1) * gap + 32, cy + 30),
        (20, 20, 20),
        -1,
    )
    # 좌→우 [빨강, 노랑, 좌회전(초록화살표), 녹색] — BGR
    lamp_color = {
        0: (40, 40, 245),     # 빨강 (H≈0)
        1: (40, 215, 245),    # 노랑
        2: (120, 230, 40),    # 초록 화살표 (H≈73 — 실측 램프 색감)
        3: (120, 230, 40),    # 녹색
    }
    for i in range(n_lamps):
        x = x0 + i * gap
        on = i in (lit_index if isinstance(lit_index, (list, tuple)) else [lit_index])
        color = lamp_color.get(i, (245, 245, 245)) if on else (55, 55, 55)
        cv2.circle(img, (x, cy), r, color, -1)
    return img


# ──────────────────────────────────────────────────────────────────
# 견고성 — 죽지 않는가
# ──────────────────────────────────────────────────────────────────
def test_detectors_survive_none_input():
    assert LaneDetector().detect(None).valid is False
    assert ConeDetector().detect(None).detected is False
    assert SignalDetector().detect(None).state is SignalState.UNKNOWN


def test_detectors_survive_blank_frame():
    blank = np.zeros((H, W, 3), np.uint8)
    LaneDetector().detect(blank)
    ConeDetector().detect(blank)
    SignalDetector().detect(blank)


def test_lidar_survives_varying_scan_length():
    """스캔 길이가 바뀌어도 죽지 않는다 — 인덱스 기반 구현의 고질병 방지."""
    trk = LidarTracker()
    for n in (180, 360, 505, 720):
        ranges = [3.0] * n
        r = trk.update(
            ranges,
            angle_min=-math.pi,
            angle_increment=2 * math.pi / n,
            now=float(n),
        )
        assert r.valid


def test_lidar_handles_inf_and_nan():
    trk = LidarTracker()
    n = 360
    ranges = [float("inf")] * n
    ranges[10] = float("nan")
    ranges[20] = 0.0
    r = trk.update(
        ranges, angle_min=-math.pi, angle_increment=2 * math.pi / n, now=1.0
    )
    assert r.front_dist == float("inf")


# ──────────────────────────────────────────────────────────────────
# 부호 — 방향이 맞는가
# ──────────────────────────────────────────────────────────────────
def test_lane_offset_sign_follows_car_position():
    """차가 왼쪽에 치우치면 목표선은 오른쪽(+)에 보여야 한다."""
    det = LaneDetector()
    centered = det.detect(road_frame(left_x=140, right_x=500))

    det2 = LaneDetector()
    # 차선을 통째로 오른쪽으로 밀면 = 차가 왼쪽에 있는 상황
    shifted = det2.detect(road_frame(left_x=240, right_x=600))

    assert shifted.offset_px > centered.offset_px


def test_lidar_front_sector_is_angle_based():
    """정면 물체는 스캔 해상도와 무관하게 정면으로 잡혀야 한다."""
    for n in (200, 400, 800):
        trk = LidarTracker()
        ranges = [5.0] * n
        # 0 rad(정면)에 해당하는 인덱스에 가까운 물체를 놓는다
        idx = int((0.0 - (-math.pi)) / (2 * math.pi / n))
        for k in range(idx - 2, idx + 3):
            ranges[k % n] = 1.1
        r = trk.update(
            ranges, angle_min=-math.pi, angle_increment=2 * math.pi / n, now=1.0
        )
        assert abs(r.front_dist - 1.1) < 0.05, f"n={n} 에서 정면 검출 실패"


def test_lidar_side_clearance():
    trk = LidarTracker()
    n = 360
    inc = 2 * math.pi / n
    ranges = [5.0] * n
    # 좌측 90° 부근을 막는다
    for k in range(n):
        a = -math.pi + k * inc
        if 0.7 < a < 1.4:
            ranges[k] = 0.4
    r = trk.update(ranges, angle_min=-math.pi, angle_increment=inc, now=1.0)
    assert r.left_clear is False
    assert r.right_clear is True


def test_cone_gate_center_between_two_rows():
    """좌우 두 줄 사이의 중앙을 잡아야 한다 — 한쪽 줄을 따라가면 안 된다."""
    img = np.full((240, W, 3), 40, np.uint8)
    # BGR 로 주황 (H≈15, S 높음, V 높음)
    orange = (30, 150, 250)
    for y in (120, 170, 220):
        cv2.circle(img, (200, y), 16, orange, -1)   # 왼쪽 줄
        cv2.circle(img, (440, y), 16, orange, -1)   # 오른쪽 줄

    r = ConeDetector().detect(img)
    assert r.detected
    assert r.gate_valid, "양쪽 줄을 모두 봐야 게이트가 성립"
    # 게이트 중앙(320)이 곧 ROI 중앙(320) → 오차 거의 0
    assert abs(r.gate_center_px) < 40, f"게이트 중앙 오차 {r.gate_center_px}"


def test_cone_gate_shifts_with_rows():
    """두 줄이 함께 왼쪽으로 밀리면 게이트 중앙도 왼쪽(-)으로."""
    img = np.full((240, W, 3), 40, np.uint8)
    orange = (30, 150, 250)
    for y in (120, 170, 220):
        cv2.circle(img, (100, y), 16, orange, -1)
        cv2.circle(img, (300, y), 16, orange, -1)
    r = ConeDetector().detect(img)
    assert r.gate_valid
    assert r.gate_center_px < -40


def test_cone_single_row_reports_invalid_gate():
    """한쪽만 보이면 게이트를 만들지 않는다 (policy 가 반발 조향으로 대체)."""
    img = np.full((240, W, 3), 40, np.uint8)
    orange = (30, 150, 250)
    for y in (120, 170, 220):
        cv2.circle(img, (150, y), 16, orange, -1)
    r = ConeDetector().detect(img)
    assert r.detected
    assert r.gate_valid is False


# ──────────────────────────────────────────────────────────────────
# 4구 신호등 — 규정 p.36 의 점등 조합
# ──────────────────────────────────────────────────────────────────
def _detect(frame):
    det = SignalDetector()
    det.config.min_radius = 10
    det.config.max_radius = 22
    det.config.roi_top = 0.0
    det.config.roi_bottom = 0.45
    det.config.roi_left = 0.15
    det.config.roi_right = 0.85
    return det.detect(frame)


def test_signal_green_only_is_go_straight():
    """좌→우 [빨강, 노랑, 좌회전, 녹색] — 4번째만 켜지면 직진."""
    r = _detect(signal_frame(lit_index=3))
    assert r.state is SignalState.GREEN
    assert r.state.is_go
    assert not r.state.allows_left


def test_signal_green_plus_left_allows_shortcut():
    """3번+4번 동시 = 직좌 동시신호 → 지름길 가능."""
    r = _detect(signal_frame(lit_index=[2, 3]))
    assert r.state is SignalState.GREEN_LEFT
    assert r.state.allows_left


def test_signal_red_is_not_go():
    r = _detect(signal_frame(lit_index=0))
    assert r.state is SignalState.RED
    assert not r.state.is_go


def test_signal_reports_gantry_span_for_lap_counting():
    """분류가 되든 안 되든 겐트리 근접 지표는 나와야 한다 (랩 카운팅용)."""
    r = _detect(signal_frame(lit_index=3))
    assert r.gantry_span_px > 0


def test_achromatic_bright_circles_are_not_a_signal():
    """천장 조명 회귀 테스트 (run4 bag 실측 실패 모드).

    무채색으로 밝은 원 4개가 일렬로 있어도 — 대회장 형광등이 정확히 이렇게
    잡힌다 — 켜진 램프도, 랩 마커도 아니어야 한다.
    """
    img = np.full((H, W, 3), 30, np.uint8)
    x0 = 320 - 3 * 46 // 2
    for i in range(4):
        cv2.circle(img, (x0 + i * 46, 110), 15, (245, 245, 245), -1)
    r = _detect(img)
    assert r.state is SignalState.UNKNOWN, "무채색 밝음은 점등이 아니다"
    assert r.gantry_span_px == 0, "무채색 원은 랩 마커가 아니다"


def test_gantry_span_requires_green_lamp():
    """랩 마커는 초록 점등에서만 나온다.

    빨간불 대기(출발 전) 장면에는 span 이 없어야 하고 — '목격 1'은 초록이
    켜지는 출발 순간에 잡히는 것이 의도된 설계다 (race_context.py 주석 참조).
    """
    assert _detect(signal_frame(lit_index=0)).gantry_span_px == 0
    assert _detect(signal_frame(lit_index=[2, 3])).gantry_span_px > 0
