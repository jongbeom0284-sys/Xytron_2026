"""랩 카운팅 검증.

랩을 하나 놓치면 3바퀴를 못 채우고, 하나 더 세면 2바퀴 만에 멈춘다.
둘 다 곧바로 실격이라 이 모듈은 오검출/중복검출 양쪽 모두를 막아야 한다.
"""

from kmu_race.core.race_context import (
    TOTAL_LAPS,
    LapTracker,
    LapTrackerConfig,
    RaceContext,
)


def feed(tracker, *, span, frames, t0=0.0, step=0.05, yaw=0.0):
    """같은 조건을 여러 프레임 먹이고 발생한 목격 수를 돌려준다."""
    hits = 0
    for i in range(frames):
        if tracker.update(
            gantry_span_px=span, now=t0 + step * i, yaw_deg=yaw
        ):
            hits += 1
    return hits, t0 + step * frames


def test_single_sighting_counts_once():
    """겐트리 앞에 오래 서 있어도 한 번만 센다."""
    trk = LapTracker()
    hits, _ = feed(trk, span=40, frames=200)
    assert hits == 1
    assert trk.sightings == 1


def test_far_gantry_is_ignored():
    """반대편 직선에서 작게 잡히는 것은 세지 않는다."""
    trk = LapTracker()
    hits, _ = feed(trk, span=10, frames=100)
    assert hits == 0
    assert trk.sightings == 0


def test_second_sighting_after_absence():
    trk = LapTracker()
    _, t = feed(trk, span=40, frames=20)          # 목격 1
    _, t = feed(trk, span=0, frames=400, t0=t)    # 한 바퀴 (20초)
    hits, _ = feed(trk, span=40, frames=20, t0=t)
    assert hits == 1
    assert trk.sightings == 2


def test_brief_flicker_does_not_recount():
    """겐트리 밑을 지나며 몇 프레임 끊겨도 다시 세지 않는다."""
    trk = LapTracker()
    _, t = feed(trk, span=40, frames=20)
    _, t = feed(trk, span=0, frames=5, t0=t)      # release_frames(12) 미만
    hits, _ = feed(trk, span=40, frames=20, t0=t)
    assert hits == 0
    assert trk.sightings == 1


def test_min_gap_blocks_rapid_recount():
    """미검출이 길어도 직전 목격에서 15초가 안 지났으면 안 센다."""
    cfg = LapTrackerConfig(min_gap_s=15.0)
    trk = LapTracker(cfg)
    _, t = feed(trk, span=40, frames=20)
    _, t = feed(trk, span=0, frames=40, t0=t)     # 2초만 경과
    hits, _ = feed(trk, span=40, frames=20, t0=t)
    assert hits == 0
    assert trk.sightings == 1


def test_lap_progression_and_finish():
    trk = LapTracker()
    t = 0.0
    for expected in (1, 2, 3):
        _, t = feed(trk, span=40, frames=20, t0=t)
        assert trk.current_lap == expected
        assert not trk.finished
        _, t = feed(trk, span=0, frames=400, t0=t)
    _, t = feed(trk, span=40, frames=20, t0=t)
    assert trk.finished, "4번째 목격 = 결승선 통과 후"
    assert trk.current_lap == TOTAL_LAPS


def test_yaw_cross_check_flags_missed_lap():
    """카메라가 겐트리를 놓쳤을 가능성을 요 적산으로 의심한다."""
    trk = LapTracker()
    feed(trk, span=40, frames=20, yaw=0.0)
    assert not trk.yaw_suggests_missed_lap(50.0)
    assert trk.yaw_suggests_missed_lap(360.0)


# ──────────────────────────────────────────────────────────────────
# 지름길 규칙 (규정 p.35)
# ──────────────────────────────────────────────────────────────────
def test_shortcut_not_allowed_on_lap1():
    ctx = RaceContext()
    ctx.lap.sightings = 1
    assert ctx.may_take_shortcut(True) is False


def test_shortcut_allowed_on_lap2_and_3():
    for lap in (2, 3):
        ctx = RaceContext()
        ctx.lap.sightings = lap
        assert ctx.may_take_shortcut(True) is True


def test_shortcut_requires_left_signal():
    ctx = RaceContext()
    ctx.lap.sightings = 2
    assert ctx.may_take_shortcut(False) is False


def test_shortcut_locked_after_use():
    ctx = RaceContext()
    ctx.lap.sightings = 2
    ctx.race_started_at = 0.0
    assert ctx.may_take_shortcut(True) is True
    ctx.commit_shortcut(10.0)
    ctx.lap.sightings = 3
    assert ctx.may_take_shortcut(True) is False
