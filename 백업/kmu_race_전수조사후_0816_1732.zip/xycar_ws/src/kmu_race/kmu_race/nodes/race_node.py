"""메인 노드 — 이 패키지에서 rclpy 를 아는 유일한 실행 진입점.

구조 원칙 (doldolmeng2/2026-kookmin-contest 의 설계를 따랐다):
    노드는 얇게. 센서 → 데이터클래스 변환, core 호출, 모터 발행만 한다.
    판단 로직은 전부 core/ 에 있고 rclpy 를 모른다. 그래서 실차 없이
    `pytest` 로 FSM 과 정책을 통째로 검증할 수 있다.

동시성:
    카메라 콜백에서 무거운 CV 를 돌리고, 별도 타이머에서 제어를 발행한다.
    콜백별 MutuallyExclusive 그룹 + MultiThreadedExecutor 를 써서 CV 가 제어
    주기를 막지 않으면서도, 같은 콜백이 자기 자신과 병렬 실행되어 낡은
    프레임이 최신 관측을 덮어쓰는 일은 없게 한다. (`rclpy.spin_once` 를
    수동으로 여러 번 부르는 방식은 콜백 지연과 프레임 드랍을 만들어 쓰지 않는다.)

대회 당일 주의:
    규정 p.16 — 실행 명령은 `ros2 launch ...` 여야 하고 심판이 화면을 봐야 한다.
    `debug_gui:=false` 로 OpenCV 창을 전부 끄고 돌릴 것. 창 19개를 띄운 채로는
    프레임이 밀려 4분 예산(p.37)을 지키기 어렵다. 상태는 로그로 보여 준다.
"""

from __future__ import annotations

import math
import time
from typing import Optional

import numpy as np
import rclpy
from cv_bridge import CvBridge
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import Image, Imu, LaserScan

from ..core.policy import DrivePolicy, PolicyConfig
from ..core.race_context import RaceContext
from ..core.race_fsm import Mode, RaceFSM
from ..core.safety import SafetyMonitor
from ..core.types import (
    ConeReading,
    LaneReading,
    LidarReading,
    Observation,
    SignalReading,
)
from ..io.motor import MotorPublisher
from ..perception.cone_detector import ConeDetector
from ..perception.lane_detector import LaneDetector
from ..perception.lidar_tracker import LidarTracker
from ..perception.signal_detector import SignalDetector


class RaceNode(Node):
    def __init__(self) -> None:
        super().__init__("kmu_race")

        # ── 파라미터 ──────────────────────────────────────────────
        self.declare_parameter("control_hz", 50.0)
        self.declare_parameter("debug_gui", False)
        self.declare_parameter("image_topic", "/image_raw")
        self.declare_parameter("scan_topic", "/scan")
        self.declare_parameter("imu_topic", "/imu")
        self.declare_parameter("motor_topic", "xycar_motor")
        self.declare_parameter("use_xycar_msgs", False)
        # 명령속도[자이카 단위] → 실제 속도[m/s] 환산. 실차에서 반드시 실측할 것.
        # 정지/주행 장애물 판별의 정확도가 여기에 달려 있다.
        self.declare_parameter("speed_to_mps", 0.08)
        self.declare_parameter("input_timeout_s", 0.35)

        self.debug_gui = bool(self.get_parameter("debug_gui").value)
        self.speed_to_mps = float(self.get_parameter("speed_to_mps").value)
        self.input_timeout = float(self.get_parameter("input_timeout_s").value)

        # ── 퍼셉션 ────────────────────────────────────────────────
        self.bridge = CvBridge()
        self.signal_det = SignalDetector()
        self.lane_det = LaneDetector()
        self.cone_det = ConeDetector()
        self.lidar_trk = LidarTracker()

        # ── core ─────────────────────────────────────────────────
        self.ctx = RaceContext()
        self.fsm = RaceFSM()
        self.policy = DrivePolicy(PolicyConfig())
        self.safety = SafetyMonitor()

        # ── 최신 관측 (콜백이 쓰고 타이머가 읽는다) ──────────────
        self._signal = SignalReading()
        self._lane = LaneReading()
        self._cone = ConeReading()
        self._lidar = LidarReading()
        self._yaw_deg = 0.0
        self._yaw_unwrapped = 0.0
        self._yaw_prev: Optional[float] = None
        self._last_image_t = 0.0
        self._last_scan_t = 0.0

        # ── ROS I/O ──────────────────────────────────────────────
        # 콜백 그룹: 서로 다른 콜백은 병렬로, '같은' 콜백은 직렬로.
        # 전부 하나의 Reentrant 그룹에 넣으면 _on_image 가 프레임 주기를
        # 넘기는 순간 자기 자신과 병렬 실행되어(cv2 는 GIL 을 놓는다) 낡은
        # 프레임이 최신 관측을 덮어쓰고 yaw 적산 RMW 가 겹친다 (리뷰 T2).
        # 그룹을 콜백별 MutuallyExclusive 로 나누면 CV 가 제어 주기를 막지
        # 않는다는 원래 목적은 그대로 달성된다.
        img_group = MutuallyExclusiveCallbackGroup()
        scan_group = MutuallyExclusiveCallbackGroup()
        imu_group = MutuallyExclusiveCallbackGroup()
        ctrl_group = MutuallyExclusiveCallbackGroup()
        sensor_qos = QoSProfile(depth=1, reliability=ReliabilityPolicy.BEST_EFFORT)

        self.create_subscription(
            Image,
            self.get_parameter("image_topic").value,
            self._on_image,
            sensor_qos,
            callback_group=img_group,
        )
        self.create_subscription(
            LaserScan,
            self.get_parameter("scan_topic").value,
            self._on_scan,
            sensor_qos,
            callback_group=scan_group,
        )
        self.create_subscription(
            Imu,
            self.get_parameter("imu_topic").value,
            self._on_imu,
            sensor_qos,
            callback_group=imu_group,
        )

        self.motor = MotorPublisher(
            self,
            topic=self.get_parameter("motor_topic").value,
            use_xycar_msgs=bool(self.get_parameter("use_xycar_msgs").value),
        )

        hz = float(self.get_parameter("control_hz").value)
        self.create_timer(1.0 / hz, self._control_step, callback_group=ctrl_group)
        self._last_mode = Mode.INIT
        self._log_throttle = 0.0
        # 요 교차검증 경고를 목격 횟수당 1번만 내기 위한 래치
        self._yaw_warned_at_sighting = -1

        self.get_logger().info(
            f"kmu_race up | debug_gui={self.debug_gui} | control={hz:.0f}Hz"
        )
        self.get_logger().info("규정 3바퀴 / 4분 / 지름길 1회 — 신호등 대기 중")

    # ── 콜백 ──────────────────────────────────────────────────────
    def _now(self) -> float:
        return self.get_clock().now().nanoseconds * 1e-9

    def _on_image(self, msg: Image) -> None:
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        except Exception as exc:                      # noqa: BLE001
            self.get_logger().warn(f"cv_bridge: {exc}")
            return

        self._signal = self.signal_det.detect(frame)
        self._lane = self.lane_det.detect(frame)

        # 라바콘 검출은 차선 detect() 가 캐시한 BEV ROI 를 재사용한다 —
        # 여기서 warp 를 또 부르면 프레임당 워프가 2회가 된다 (리뷰 E1).
        bev_roi = self.lane_det.last_bev_roi
        self._cone = self.cone_det.detect(bev_roi)

        self._last_image_t = self._now()

        if self.debug_gui:
            self._draw_debug(frame, bev_roi)

    def _on_scan(self, msg: LaserScan) -> None:
        self._lidar = self.lidar_trk.update(
            msg.ranges,
            angle_min=msg.angle_min,
            angle_increment=msg.angle_increment,
            now=self._now(),
        )
        self._last_scan_t = self._now()

    def _on_imu(self, msg: Imu) -> None:
        q = msg.orientation
        siny = 2.0 * (q.w * q.z + q.x * q.y)
        cosy = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        yaw = math.degrees(math.atan2(siny, cosy))

        # ±180 경계를 펴서 누적한다. 랩 카운팅 교차검증과 지름길 좌회전 완료
        # 판정이 '누적 회전량'을 쓰기 때문에 wrap 이 있으면 안 된다.
        if self._yaw_prev is not None:
            d = yaw - self._yaw_prev
            if d > 180.0:
                d -= 360.0
            elif d < -180.0:
                d += 360.0
            self._yaw_unwrapped += d
        self._yaw_prev = yaw
        self._yaw_deg = self._yaw_unwrapped

    # ── 제어 루프 ─────────────────────────────────────────────────
    def _control_step(self) -> None:
        now = self._now()
        camera_ok = (now - self._last_image_t) < self.input_timeout
        # 카메라가 죽으면 마지막 관측이 동결된 채 매 틱 재사용된다 — 특히
        # 동결된 GREEN_LEFT 가 지름길 래치를 계속 갱신하는 사고를 원천 차단
        # 하기 위해, 신선하지 않은 신호 관측은 빈 값으로 강등한다.
        obs = Observation(
            now=now,
            signal=self._signal if camera_ok else SignalReading(),
            lane=self._lane,
            lidar=self._lidar,
            cone=self._cone,
            yaw_deg=self._yaw_deg,
            ego_speed_mps=self.motor.last_speed * self.speed_to_mps,
            camera_ok=camera_ok,
            lidar_ok=(now - self._last_scan_t) < self.input_timeout,
        )

        racing = self.fsm.state not in (Mode.INIT, Mode.WAIT_GREEN)
        decision = self.safety.evaluate(obs, racing=racing)

        # policy 가 보고한 기동 종료를 FSM 에 넘겨준다.
        self.fsm.maneuver_done = self.policy.maneuver_done

        transition = self.fsm.step(obs, self.ctx, decision)
        if transition.changed:
            self.get_logger().warning(
                f"[{transition.source.value} → {transition.target.value}] "
                f"{transition.reason} | lap {self.ctx.lap.current_lap}/3 "
                f"| t={self.ctx.elapsed(now):.1f}s"
            )
            if transition.target is Mode.LANE_DRIVE:
                # 기동에서 빠져나올 때 PID 적분/스무더를 털어 준다.
                self.policy.pid.reset()

        cmd = self.policy.update(self.fsm.state, obs, self.ctx, decision)
        self.motor.publish(cmd.steer, cmd.speed)

        if self.fsm.state is Mode.FINISH and self._last_mode is not Mode.FINISH:
            self.motor.stop()
            self._report()
        self._last_mode = self.fsm.state

        # IMU 요 적산 교차검증 — 겐트리 목격을 놓쳤을 가능성을 알린다.
        # 자동 보정은 하지 않는다 (오검으로 랩을 잘못 올리면 실격,
        # race_context.py 설계 노트 참조). 목격 횟수당 1번만 경고.
        if (
            self.fsm.state not in (Mode.INIT, Mode.WAIT_GREEN)
            and self.ctx.lap.yaw_suggests_missed_lap(obs.yaw_deg)
            and self._yaw_warned_at_sighting != self.ctx.lap.sightings
        ):
            self._yaw_warned_at_sighting = self.ctx.lap.sightings
            self.get_logger().warning(
                f"⚠ 요 적산 랩 누락 의심 — 목격 {self.ctx.lap.sightings}회 상태로 "
                f"한 바퀴치(≥{self.ctx.lap.config.yaw_per_lap_deg:.0f}°) 이상 회전. "
                f"겐트리를 놓쳤다면 min_gantry_span_px 가 너무 높은 것이다"
            )

        # 심판이 화면으로 진행 상황을 봐야 하므로(p.16) 상태를 주기적으로 찍는다.
        if now - self._log_throttle > 1.0:
            self._log_throttle = now
            self.get_logger().info(
                f"{self.fsm.state.value:<12} lap{self.ctx.lap.current_lap}/3 "
                f"t={self.ctx.elapsed(now):5.1f}s "
                f"steer={cmd.steer:+6.1f} v={cmd.speed:5.1f} "
                f"sig={obs.signal.state.value:<10} "
                f"front={obs.lidar.front_dist:4.2f}m "
                f"{'SHORTCUT-USED' if self.ctx.shortcut_used else ''}"
            )

    def _report(self) -> None:
        el = self.ctx.elapsed(self._now())
        self.get_logger().warning("=" * 52)
        self.get_logger().warning(f"  경주 종료  주행시간 {el:.2f}s / 240s 제한")
        self.get_logger().warning(
            f"  지름길 {'사용' if self.ctx.shortcut_used else '미사용'}"
            + (
                f" (lap {self.ctx.left_signal_seen_on_lap})"
                if self.ctx.shortcut_used
                else ""
            )
        )
        for line in self.ctx.events:
            self.get_logger().warning(f"  {line}")
        self.get_logger().warning("=" * 52)

    # ── 디버그 시각화 (튜닝 전용) ─────────────────────────────────
    def _draw_debug(self, frame, bev_roi) -> None:
        import cv2

        sig = self.signal_det.annotate()
        if sig is not None and sig.size:
            cv2.imshow("signal", sig)

        overlay = bev_roi.copy()
        h_roi, w_roi = overlay.shape[:2]
        cx = w_roi // 2
        cv2.line(overlay, (cx, 0), (cx, h_roi), (80, 80, 80), 1)
        px = int(cx + self._lane.offset_px)
        cv2.line(overlay, (px, 0), (px, h_roi), (0, 220, 0), 2)
        if self._cone.gate_valid:
            gx = int(cx + self._cone.gate_center_px)
            cv2.line(overlay, (gx, 0), (gx, h_roi), (0, 140, 255), 2)
        cv2.putText(
            overlay,
            f"{self.fsm.state.value} lap{self.ctx.lap.current_lap} "
            f"off={self._lane.offset_px:+.0f} cone={self._cone.orange_px}",
            (8, 20),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (255, 255, 255),
            1,
        )
        cv2.imshow("bev", overlay)
        cv2.waitKey(1)


def main(args=None) -> None:
    rclpy.init(args=args)
    node = RaceNode()
    executor = MultiThreadedExecutor(num_threads=3)
    executor.add_node(node)
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        try:
            node.motor.stop()
        except Exception:                              # noqa: BLE001
            pass
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
