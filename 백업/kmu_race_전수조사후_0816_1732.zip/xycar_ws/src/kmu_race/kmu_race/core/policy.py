"""모드 → 주행명령. core 계층의 최상단이며 여전히 rclpy 를 모른다.

FSM 이 '무엇을 하는 중인가'를 정하고, 여기서 '그래서 바퀴를 어떻게 돌릴까'를 만든다.
둘을 나눠 놓은 덕에 test/ 에서 관측을 손으로 지어내 명령까지 끝단 검증할 수 있다.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from .control import PixelPID, SteerSmoother, pure_pursuit_steer
from .race_context import RaceContext
from .race_fsm import Mode
from .safety import SafetyDecision
from .speed_policy import SpeedConfig, SpeedPolicy
from .target_passing import PassConfig, TargetPassing
from .types import DriveCommand, Observation


@dataclass
class PolicyConfig:
    max_steer: float = 50.0
    pid: PixelPID = field(default_factory=PixelPID)
    speed: SpeedConfig = field(default_factory=SpeedConfig)
    pass_static: PassConfig = field(
        default_factory=lambda: PassConfig(
            shift_speed=11.0, alongside_speed=14.0, return_speed=13.0
        )
    )
    pass_moving: PassConfig = field(default_factory=PassConfig)
    smoother: SteerSmoother = field(default_factory=SteerSmoother)

    # ── 라바콘 ──
    # 게이트 중앙을 향하는 퓨어 퍼수트 전방주시거리 [m]
    cone_lookahead_m: float = 0.75
    # BEV 픽셀 → 미터 환산. 실차 캘리브레이션 값으로 반드시 교체할 것.
    px_per_m: float = 420.0
    # 한쪽 콘만 보일 때 밀어내는 세기 [deg / 정규화오차]
    cone_repulse_gain: float = 26.0

    # ── 지름길 ──
    # 진입 좌회전은 개루프로 돈다. 분기점에서는 차선 도색이 끊겨 차선검출을
    # 믿을 수 없기 때문이다. 요 변화량으로 종료를 판정한다(FSM 담당).
    shortcut_steer_deg: float = -34.0

    # ── 출발 직진 홀드 ──
    # 출발 위치에서는 겐트리 지주·신호등 기둥이 차선으로 오검되기 쉽다.
    # 2026 참가팀 셋(jeonghun43·pumkyQ·UMK)이 독립적으로 같은 가드에 수렴한
    # 공통 실패 모드라, 출발 후 이 시간 동안은 조향을 중립에 고정한다.
    # 출발 시 차는 정지 상태에서 정렬돼 있으므로 짧은 맹목 직진은 안전하다.
    start_straight_hold_s: float = 1.2

    # ── 열화 모드 ──
    # 카메라가 잠깐 죽었을 때 마지막 조향을 이만큼 감쇠시키며 유지한다.
    # 규정 p.21 상 멈추는 것이 가장 비싸므로 직진 크립으로 버틴다.
    degraded_steer_decay: float = 0.90


class DrivePolicy:
    def __init__(self, config: Optional[PolicyConfig] = None) -> None:
        self.config = config or PolicyConfig()
        self.pid = self.config.pid
        self.speed = SpeedPolicy(self.config.speed)
        self.smoother = self.config.smoother
        self.pass_static = TargetPassing(
            moving=False, config=self.config.pass_static
        )
        self.pass_moving = TargetPassing(
            moving=True, config=self.config.pass_moving
        )
        self._last_steer = 0.0
        self._last_pass_done = False
        self._prev_mode: Optional[Mode] = None

    @property
    def maneuver_done(self) -> bool:
        """직전 update() 에서 통과 기동이 끝났는가. FSM 이 읽어 간다."""
        return self._last_pass_done

    def reset(self) -> None:
        self.pid.reset()
        self.speed.reset()
        self.smoother.reset()
        self.pass_static.reset()
        self.pass_moving.reset()
        self._last_steer = 0.0
        self._last_pass_done = False

    # ──────────────────────────────────────────────────────────────
    def update(
        self,
        mode: Mode,
        obs: Observation,
        ctx: RaceContext,
        safety: SafetyDecision,
    ) -> DriveCommand:
        cfg = self.config
        self._last_pass_done = False

        # 기동 상태 위생: 통과 컨트롤러는 모드에 '진입하는 순간' 백지여야 한다.
        # 승격(AVOID→OVERTAKE)·STOP 개입으로 중간 상태(_started_at 등)가 남으면
        # 다음 진입 첫 틱에 6초 타임아웃이 걸려 가짜 '통과 완료'가 나온다.
        if mode is not self._prev_mode:
            if mode is Mode.AVOID_STATIC:
                self.pass_static.reset()
            elif mode is Mode.OVERTAKE:
                self.pass_moving.reset()
            self._prev_mode = mode

        if mode in (Mode.FINISH, Mode.STOP):
            self.speed.reset()
            self.pass_static.reset()
            self.pass_moving.reset()
            return DriveCommand(0.0, 0.0, mode.value)

        if mode in (Mode.INIT, Mode.WAIT_GREEN):
            # INIT: 입력 대기 중 — 여기서 기본 분기(차선주행)로 떨어지면
            # 런치 직후 1~2초간 실제 주행 명령이 나간다 (2026-08-13 실차
            # 스모크 테스트에서 v=17.7 발행 실측). 출발 전에는 무조건 정지.
            # WAIT_GREEN: 규정 p.19 — 신호등 앞 정차 대기. 조향 중립.
            return DriveCommand(0.0, 0.0, mode.value)

        # 카메라가 상했으면 마지막 조향을 감쇠시키며 저속 직진으로 버틴다.
        if safety.degraded and not obs.camera_ok:
            steer = self._last_steer * cfg.degraded_steer_decay
            self._last_steer = steer
            target = self.speed.target_for(
                mode.value, steer_deg=steer, time_pressure=0.0, degraded=True
            )
            return DriveCommand(
                steer, self.speed.step(target, obs.now), "DEGRADED"
            ).clamped(cfg.max_steer, cfg.speed.max_speed)

        steer, speed_override = self._steer_for(mode, obs, ctx)

        steer = self.smoother.update(steer, obs.now)
        self._last_steer = steer

        target = self.speed.target_for(
            mode.value,
            steer_deg=steer,
            time_pressure=ctx.time_pressure(obs.now),
            override=speed_override,
            degraded=safety.degraded,
        )
        speed = self.speed.step(target, obs.now)

        return DriveCommand(steer, speed, mode.value).clamped(
            cfg.max_steer, cfg.speed.max_speed
        )

    # ──────────────────────────────────────────────────────────────
    def _steer_for(
        self, mode: Mode, obs: Observation, ctx: RaceContext
    ) -> tuple[float, Optional[float]]:
        """모드별 조향 [deg] 과 속도 오버라이드를 만든다."""
        cfg = self.config

        if mode is Mode.SHORTCUT:
            # 개루프 좌회전. 분기점은 차선 도색이 끊겨 있어 검출을 믿지 않는다.
            return cfg.shortcut_steer_deg, None

        if mode is Mode.CONE_DRIVE:
            return self._cone_steer(obs), None

        if mode in (Mode.AVOID_STATIC, Mode.OVERTAKE):
            passer = (
                self.pass_moving if mode is Mode.OVERTAKE else self.pass_static
            )
            # 기동 중에는 넓은 코리도로 타겟을 계속 추적한다 — 기본 0.45m 는
            # 자기 횡이동(0.7m)만으로 타겟이 사라져 조기 복귀를 만든다(리뷰 C2).
            result = passer.update(
                target=obs.lidar.nearest_front(
                    max_lateral=passer.config.track_corridor_m
                ),
                lane_offset_px=obs.lane.offset_px,
                lane_lookahead_px=obs.lane.lookahead_px,
                lane_side=obs.lane.lane_side,
                left_clear=obs.lidar.left_clear,
                right_clear=obs.lidar.right_clear,
                now=obs.now,
            )
            self._last_pass_done = result.done
            return self.pid.update(result.lateral_offset_px), result.speed

        # LANE_DRIVE (및 그 외 기본)
        if (
            ctx.race_started_at is not None
            and (obs.now - ctx.race_started_at) < cfg.start_straight_hold_s
        ):
            # 출발 직진 홀드 — 겐트리 지주 오검으로 인한 초반 급조향 차단
            return 0.0, None
        return self._lane_steer(obs), None

    def _lane_steer(self, obs: Observation) -> float:
        """차선 중앙 추종. 전방주시점을 섞어 곡률에 선행 반응한다."""
        lane = obs.lane
        if not lane.valid:
            # 양쪽 다 못 봤다. 직전 조향을 유지하며 빠져나가길 기다린다.
            return self._last_steer * 0.95
        error = 0.6 * lane.offset_px + 0.4 * lane.lookahead_px
        return self.pid.update(error)

    def _cone_steer(self, obs: Observation) -> float:
        """라바콘 구간 조향.

        규정 p.23~25 의 도면은 콘이 **좌우 두 줄**로 놓이고 그 사이를 지나가는
        형태다. 그래서 '주황 덩어리 하나를 따라간다'가 아니라 '좌우 게이트의
        중앙을 지난다'로 푼다.

        한쪽 줄만 보이면 게이트를 만들 수 없으므로 보이는 줄에서 밀어내는
        반발 조향으로 대체한다 — 콘을 건드리면 개당 3초(p.24)다.
        """
        cfg = self.config
        cone = obs.cone

        if cone.gate_valid:
            # 게이트 중앙(px)을 차량 기준 목표점(m)으로 바꿔 퓨어 퍼수트로 간다.
            lateral_m = cone.gate_center_px / max(1.0, cfg.px_per_m)
            return pure_pursuit_steer(
                cfg.cone_lookahead_m, -lateral_m, max_steer=cfg.max_steer
            )

        if cone.left_cone_px > 0 or cone.right_cone_px > 0:
            # 보이는 쪽에서 밀어낸다. 좌측 콘이 많으면 우측으로.
            total = float(cone.left_cone_px + cone.right_cone_px)
            bias = (cone.left_cone_px - cone.right_cone_px) / max(1.0, total)
            return max(
                -cfg.max_steer,
                min(cfg.max_steer, bias * cfg.cone_repulse_gain),
            )

        # 콘을 놓쳤다. 차선주행으로 버틴다.
        return self._lane_steer(obs)


__all__ = ["PolicyConfig", "DrivePolicy"]
